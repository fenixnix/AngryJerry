#include "aj_endless.h"
#include "render/nglrender.h"
#include "aj_input.h"
#include "b2physx.h"
#include "global.h"
#include "aj_avatar.h"
#include "aj_map.h"
#include "FSM/fsm.h"
#include "FSM/aj_gamemenu.h"
#include "FSM/aj_deadmenu.h"
#include "objmngr.h"
#include "time.h"

AJ_Endless::AJ_Endless()
{
    lk = false;
    rk = false;
    mouseLb = false;
    ///time random seed gen
    srand(time(NULL));
}

bool AJ_Endless::onEnter()
{
    //cout<<__FUNCTION__<<endl;
    B2Physx::the()->init(0,-9.8);
    //cout<<__FUNCTION__<<__LINE__<<endl;
    AJ_Map::the()->init(rand());
    //cout<<__FUNCTION__<<__LINE__<<endl;
    AJ_Map::the()->generate(0);
    //cout<<__FUNCTION__<<__LINE__<<endl;
    AJ_Avatar::the()->create(0,2);
    //cout<<__FUNCTION__<<__LINE__<<endl;
    return true;
}

bool AJ_Endless::onExit()
{
    ObjMngr::the()->destoryAll();
    AJ_Map::the()->release();
    AJ_Avatar::the()->release();
    return true;
}

void AJ_Endless::update()
{
    AJ_Input::the()->update();
    AJ_Avatar::the()->update();
    ObjMngr::the()->update();
    B2Physx::the()->update();
    if(lk){
        AJ_Avatar::the()->force(-3,0);
    }
    if(rk){
        AJ_Avatar::the()->force(3,0);
    }
    if(mouseLb){
        AJ_Avatar::the()->charge();
    }
    if(!ObjMngr::the()->has(AJ_Avatar::the()->avatarID)){
        FSM::the()->pushState(new AJ_DeadMenu);
    }
}

void AJ_Endless::render()
{
    NGLRender* render = NGLRender::the();
    NGLWindow * w = render->getWindow(NGLRender::windowGame);
    w->setOrtho();
    w->setCamera(0,0);
    render->setVP(w);

    AJ_Avatar::the()->render();

    if(Global::the()->isDrawDebug){
        B2Physx::the()->render();
    }


}

bool AJ_Endless::injectKeyDown(int keyCode)
{
    //cout<<__FUNCTION__<<endl;
    if(keyCode == SDL_SCANCODE_A){
        lk = true;
    }
    if(keyCode == SDL_SCANCODE_D){
        rk = true;
    }

    if(lk^rk){

    }

    if(keyCode == SDL_SCANCODE_ESCAPE){
        FSM::the()->pushState(new AJ_GameMenu);
    }

    return true;
}

bool AJ_Endless::injectKeyUp(int keyCode)
{
    //cout<<__FUNCTION__<<endl;
    if(keyCode == SDL_SCANCODE_A){
        lk = false;
    }
    if(keyCode == SDL_SCANCODE_D){
        rk = false;
    }
    return true;
}

bool AJ_Endless::injectMouseLeftDown()
{
    //cout<<__FUNCTION__<<endl;
    mouseLb = true;
    return true;
}

bool AJ_Endless::injectMouseLeftUp()
{
    //cout<<__FUNCTION__<<endl;
    mouseLb = false;
    NGLRender::the()->getMousePos(mx,my,mz);
    AJ_Avatar::the()->shoot(mx,my);
    return true;
}
