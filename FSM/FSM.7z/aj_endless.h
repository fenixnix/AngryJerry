#ifndef AJ_ENDLESS_H
#define AJ_ENDLESS_H

#include "FSM/finitystate.h"

class AJ_Endless : public FinityState
{
public:
    AJ_Endless();
    bool onEnter();
    bool onExit();
    void update();
    void render();
    bool injectKeyDown(int keyCode);
    bool injectKeyUp(int keyCode);
    bool injectMouseLeftDown();
    bool injectMouseLeftUp();
private:
    bool lk;
    bool rk;
    bool mouseLb;
    float mx,my,mz;
};

#endif // AJ_ENDLESS_H
